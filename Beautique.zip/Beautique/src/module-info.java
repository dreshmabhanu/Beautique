/**
 * 
 */
/**
 * 
 */
module Beautique {
}